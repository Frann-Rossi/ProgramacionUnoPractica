#include <stdio.h>
#include <stdlib.h>

//prototipados:
float calcularTotal(int , float);
float calcularDescuento(float , int);
float calcularTotalAPagar(float , float);
void mostrarDetalle(int , float , float , float , float);
void realizarVenta();

int main()
{
    realizarVenta();
    return 0;
}

/*
1) Hacer una funci�n que reciba como par�metro la cantidad de productos y el
precio, y retorne el monto total de la venta.
*/
float calcularTotal(int cantProductos, float precio){

    float montoTotal = cantProductos * precio;

    return montoTotal;
}

/*
2) Una funci�n para determinar y calcular el descuento a aplicar (si es que tiene).
Por par�metro debe ingresar el monto total de la compra y la cantidad de
producto comprado. Si el monto de la compra supera los $50.000 y son m�s de
10 productos, tiene un descuento del 15%. Si la compra supera los $100.000 y
la cantidad de productos es 20 o m�s, tiene un descuento del 20%. Si no cumple
ninguno de los requisitos, no se le aplica descuento alguno. La funci�n debe
calcular y retornar el monto en pesos a descontar del monto total de la compra.
*/
float calcularDescuento(float montoTotal, int cantComprada){

    float descuento = 0;
    if(montoTotal>100000 && cantComprada>20){
        descuento = 0.2;
    }else if(montoTotal > 50000 && cantComprada>10){
        descuento = 0.15;
    }

    float montoADescontar = montoTotal * descuento;

    return montoADescontar;
}

/*
3) Hacer una funci�n que reciba por par�metro el monto total de la compra y el
monto a descontar, haga el c�lculo correspondiente para obtener el monto a
pagar con el descuento, y lo retorne.
*/
float calcularTotalAPagar(float montoTotal, float montoADescontar){

    float totalAPagar = montoTotal - montoADescontar;

    return totalAPagar;
}

/*
4) Hacer una funci�n que muestre por pantalla el detalle de la compra. Ejemplo:
Cantidad de productos ��������� 12 un.
Precio por producto ����������.. $ 200
Total parcial �������������. $ 2400
Descuento aplicado ���������.... -$ 360
Monto a pagar �����������.... $ 2040
*/
void mostrarDetalle(int cantProductos, float precioUnitario, float total, float descuento, float aPagar){
    printf("Cant. de productos:..... %iun.\nPrecio unitario:.....$%.2f\nTotal parcial:.....$%.2f\nDescuento aplicado:.....$%.2f\nMonto a pagar:.....$%.2f",cantProductos, precioUnitario, total, descuento, aPagar);
}

/*
5) Hacer una funci�n que realice una venta. Para ello, primero se le pedir� al
usuario del sistema que ingrese que la cantidad de productos comprados por el
cliente y el precio por unidad del producto. Luego, dicha funci�n principal tiene
que llamar a todas las anteriores (que hacen las veces de funciones auxiliares
de la funci�n principal de venta) para poder calcular el total de la compra, calcular
el descuento a aplicar, calcular el total de la compra con descuento, y finalmente
mostrar el detalle de la compra.
*/
void realizarVenta(){
    int cantProductos;
    float precioUnitario;

    printf("ingrese la cantidad de productos a comprar: ");
    scanf("%i", &cantProductos);

    printf("ingrese el precio unitario: ");
    scanf("%f", &precioUnitario);

    float total = calcularTotal(cantProductos, precioUnitario);

    float descuento = calcularDescuento(total, cantProductos);

    float aPagar = calcularTotalAPagar(total, descuento);

    mostrarDetalle(cantProductos, precioUnitario, total, descuento, aPagar);
}

